import brain_games.brain_calc


def main():
    print('Welcome to the Brain Games!\nWhat is the result of the expression?')
    brain_games.brain_calc.run()


if __name__ == '__main__':
    main()
