import brain_games.brain_even


def main():
    print('Welcome to the Brain Games!\nAnswer "yes" if number even otherwise answer "no".')
    brain_games.brain_even.run()


if __name__ == '__main__':
    main()
