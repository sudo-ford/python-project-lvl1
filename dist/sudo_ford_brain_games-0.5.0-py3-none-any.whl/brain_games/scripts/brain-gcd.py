import brain_games.brain_gcd


def main():
    print('Welcome to the Brain Games!\nFind the greatest common divisor of given numbers.')
    brain_games.brain_gcd.run()


if __name__ == '__main__':
    main()
