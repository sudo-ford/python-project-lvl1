import brain_games.brain_progression


def main():
    print('Welcome to the Brain Games!\nWhat number is missing in the progression?')
    brain_games.brain_progression.run()


if __name__ == '__main__':
    main()
