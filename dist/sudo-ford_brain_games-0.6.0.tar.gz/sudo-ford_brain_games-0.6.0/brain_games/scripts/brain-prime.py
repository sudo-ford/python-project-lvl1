import brain_games.brain_prime


def main():
    print('Welcome to the Brain Games!\nAnswer "yes" if given number is prime. Otherwise answer "no".')
    brain_games.brain_prime.run()


if __name__ == '__main__':
    main()
